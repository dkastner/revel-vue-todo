package repositories

import (
	"todo/app/entities"

	gorm "github.com/jinzhu/gorm"
)

type TodosRepository struct {
	DB *gorm.DB
}

func (r TodosRepository) AllTodos() []entities.Todo {
	var todos []entities.Todo

	if err := r.DB.Find(&todos); err != nil {
		panic(err)
	}

	return todos
}
