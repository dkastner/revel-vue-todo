package controllers

import (
	// "todo/app/entities"

	// gorm "github.com/revel/modules/orm/gorm/app"
	"github.com/revel/revel"
)

func initializeDB() {
	// gorm.DB.AutoMigrate(&entities.Todo{})
}

func init() {
	revel.OnAppStart(initializeDB)
}
