package controllers

import (
	gormc "github.com/revel/modules/orm/gorm/app/controllers"
	"github.com/revel/revel"
)

type TodosController struct {
	*gormc.Controller
	// *revel.Controller
}

type todoItem struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
}

func (c TodosController) Index() revel.Result {
	// c.Response.Out.Header().Add("Access-Control-Allow-Origin", "*")

	// repo := repositories.TodosRepository{DB: c.DB}

	// return c.RenderJSON(repo.AllTodos())
	return c.RenderJSON(todoItem{})
}
