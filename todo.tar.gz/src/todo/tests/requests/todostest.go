package tests

import (
	"encoding/json"

	"github.com/revel/revel/testing"
)

type TodosTest struct {
	testing.TestSuite
}

type todosResponseJsonItem struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
}

func (t *TodosTest) TestThatIndexPageWorks() {
	t.Get("/api/todos")
	t.AssertOk()
	t.AssertContentType("application/json; charset=utf-8")

	expected := []todosResponseJsonItem{
		todosResponseJsonItem{
			ID:   1,
			Name: "Do the dumb things I gotta do",
		},
		todosResponseJsonItem{
			ID:   2,
			Name: "Touch the puppet head",
		},
	}

	actual := []todosResponseJsonItem{}
	if err := json.Unmarshal(t.ResponseBody, &actual); err != nil {
		panic(err)
	}

	t.AssertEqual(expected, actual)
}
