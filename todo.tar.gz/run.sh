#!/bin/sh
SCRIPTPATH=$(cd "$(dirname "$0")"; pwd)
"$SCRIPTPATH/todo" -importPath todo -srcPath "$SCRIPTPATH/src" -runMode dev
